import React from "react";
import ReactDOM from "react-dom";
function App() {
  // import React from "react";

  var count = 0;
  function increase() {
    // return ++count;
    // alert("i got clicked");
    count++;
    ReactDOM.render(
      <div className="container">
        <h1>{count}</h1>
        <button onClick={increase}>+</button>
      </div>,
      document.getElementById("root")
    );
    // when we click on increase it increases count but ui is same
    // we want t render after clicking the button one way  is to call reactdom.render again but thats ineeficient
  }
  return (
    <div className="container">
      <h1>{count}</h1>
      <button onClick={increase}>+</button>
    </div>
  );
}
export default App;
