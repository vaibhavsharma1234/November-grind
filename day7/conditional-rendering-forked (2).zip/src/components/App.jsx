import React, { useState } from "react";
import Form from "./Form";
import Date from "./Date";
var isLoggedIn = false; //initially . change when loged in
// function renderConditionally() {
//   if (isLoggedIn === true) {
//     return <h1>Hello</h1>;
//   } else {
//     return <Form button="submit" />;
//   }
// }
// function App() {
//   return <div className="container">{renderConditionally()}</div>;
// }
//const currentTime = new Date().getHours();

function App() {
  const [data, setData] = useState("");

  return (
    <div className="container">
      <Date setData={setData} />
      <p>H</p>
      <p>{data}</p>
    </div>
  );
}

export default App;
