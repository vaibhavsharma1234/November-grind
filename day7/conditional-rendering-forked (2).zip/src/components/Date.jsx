import React from "react";

function Date({ setData, ...props }) {
  const chnageValue = () => {
    alert("Hello");
    setData(() => "Akshat");
  };
  return (
    <>
      Hello
      <p onClick={chnageValue}>ClickMe</p>
    </>
  );
}
export default Date;
