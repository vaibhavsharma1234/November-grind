import React from "react";
import Form from "./Form";
var isLoggedIn = false; //initially . change when loged in
// function renderConditionally() {
//   if (isLoggedIn === true) {
//     return <h1>Hello</h1>;
//   } else {
//     return <Form button="submit" />;
//   }
// }
// function App() {
//   return <div className="container">{renderConditionally()}</div>;
// }
const currentTime = new Date().getHours();

function App() {
  return (
    <div className="container">
      {/* {isLoggedIn === true ? <h1>Hello</h1> : <Form button="submit" />} */}
      {/* {currentTime < 12 ? <h1>hello</h1>:null}  */}
      {currentTime < 12 && <h1>hello</h1>}
      {/* this does the same thing */}
    </div>
  );
}

export default App;
