var numbers = [3, 56, 2, 48, 5];
// function double(x) {
//   return x * 2;
//   // it return doubling
// }
//Map -Create a new array by doing something with each item in an array.
// map ke function ke andar we pass another function
//Filter - Create a new array by keeping the items that return true.
const arr = numbers.filter(function (num) {
  return num > 10;
  // means only those numbers will be there
});
console.log(arr);
// const newNumbers = numbers.map(double);
// console.log(newNumbers);
// map returns the newly array
var newNumbers = [];
function double(x) {
  newNumbers.push(x * 2);
}
numbers.forEach(function (num) {
  if (num < 10) {
    console.log(num);
  }
});
numbers.forEach(double);
console.log(newNumbers);

//Reduce - Accumulate a value by doing something to each item in an array.
//add all numbers
var sum = 0;
numbers.forEach(function (num) {
  sum += num;
});
console.log(sum);
var newnum = numbers.reduce(function (accumulator, currentnumber) {
  return accumulator + currentnumber;
});
console.log(newnum);

//Find - find the first item that matches from an array.
// const num1 = numbers.find(function (num) {
//   return num > 10;
// });
// console.log(num1);

//FindIndex - find the index of the first item that matches.
const num1 = numbers.findIndex(function (num) {
  return num > 10;
});
console.log(num1);
