import React, { useState } from "react";

function CreateArea(props) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  function handle1(event) {
    const newt = event.target.value;
    setTitle(newt);
  }
  function handle2(event) {
    const newt = event.target.value;
    setContent(newt);
  }
  return (
    <div>
      <form>
        <input
          onChange={handle1}
          name="title"
          placeholder="Title"
          value={title}
        />
        <textarea
          onChange={handle2}
          name="content"
          placeholder="Take a note..."
          rows="3"
          value={content}
        />
        <button
          onClick={(event) => {
            event.preventDefault();
            props.addNote(title, content);
            setContent("");
            setTitle("");
          }}
        >
          Add
        </button>
      </form>
    </div>
  );
}

export default CreateArea;
